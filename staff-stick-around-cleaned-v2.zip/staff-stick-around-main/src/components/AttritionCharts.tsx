import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Area, AreaChart
} from "recharts";
import {
  attritionByDepartment, attritionByAgeGroup, salaryVsAttrition,
  satisfactionVsAttrition, tenureVsAttrition, genderDistribution
} from "@/data/hrData";

const COLORS = [
  "hsl(199, 89%, 48%)", "hsl(25, 95%, 53%)", "hsl(142, 71%, 45%)",
  "hsl(262, 83%, 58%)", "hsl(346, 77%, 50%)", "hsl(45, 93%, 47%)"
];

const tooltipStyle = {
  contentStyle: {
    background: "hsl(222, 25%, 11%)",
    border: "1px solid hsl(220, 18%, 18%)",
    borderRadius: "8px",
    fontSize: "12px",
    color: "hsl(210, 20%, 92%)",
  },
};

const ChartCard = ({ title, children, className = "" }: { title: string; children: React.ReactNode; className?: string }) => (
  <div className={`glass-card rounded-xl p-6 ${className}`}>
    <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">{title}</h3>
    {children}
  </div>
);

const AttritionCharts = () => {
  const deptData = attritionByDepartment();
  const ageData = attritionByAgeGroup();
  const salaryData = salaryVsAttrition();
  const satData = satisfactionVsAttrition();
  const tenureData = tenureVsAttrition();
  const genderData = genderDistribution();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <ChartCard title="Attrition Rate by Department">
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={deptData} barSize={32}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 18%, 18%)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} />
            <YAxis tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} unit="%" />
            <Tooltip {...tooltipStyle} />
            <Bar dataKey="rate" fill="hsl(199, 89%, 48%)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Attrition by Age Group">
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={ageData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 18%, 18%)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} />
            <YAxis tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} unit="%" />
            <Tooltip {...tooltipStyle} />
            <Area type="monotone" dataKey="rate" stroke="hsl(25, 95%, 53%)" fill="hsl(25, 95%, 53%)" fillOpacity={0.15} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Salary Range vs Attrition Rate">
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={salaryData} barSize={32}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 18%, 18%)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} />
            <YAxis tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} unit="%" />
            <Tooltip {...tooltipStyle} />
            <Bar dataKey="rate" radius={[6, 6, 0, 0]}>
              {salaryData.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Job Satisfaction vs Attrition">
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={satData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 18%, 18%)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} />
            <YAxis tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} unit="%" />
            <Tooltip {...tooltipStyle} />
            <Line type="monotone" dataKey="rate" stroke="hsl(142, 71%, 45%)" strokeWidth={3} dot={{ fill: "hsl(142, 71%, 45%)", r: 5 }} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Tenure vs Attrition Rate">
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={tenureData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 18%, 18%)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} />
            <YAxis tick={{ fontSize: 11, fill: "hsl(215, 15%, 55%)" }} unit="%" />
            <Tooltip {...tooltipStyle} />
            <Area type="monotone" dataKey="rate" stroke="hsl(262, 83%, 58%)" fill="hsl(262, 83%, 58%)" fillOpacity={0.15} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Gender Distribution & Attrition">
        <div className="flex items-center justify-center h-[280px]">
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={genderData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} dataKey="total" label={({ name, rate }) => `${name}: ${rate}%`}>
                {genderData.map((_, i) => (
                  <Cell key={i} fill={COLORS[i]} />
                ))}
              </Pie>
              <Tooltip {...tooltipStyle} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </ChartCard>
    </div>
  );
};

export default AttritionCharts;
