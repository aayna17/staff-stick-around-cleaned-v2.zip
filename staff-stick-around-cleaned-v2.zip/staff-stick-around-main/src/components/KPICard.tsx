import { Users, TrendingDown, DollarSign, Star, Clock, Activity } from "lucide-react";

interface KPICardProps {
  title: string;
  value: string;
  subtitle: string;
  icon: "users" | "trending" | "dollar" | "star" | "clock" | "activity";
  trend?: string;
  trendUp?: boolean;
  delay?: number;
}

const iconMap = {
  users: Users,
  trending: TrendingDown,
  dollar: DollarSign,
  star: Star,
  clock: Clock,
  activity: Activity,
};

const KPICard = ({ title, value, subtitle, icon, trend, trendUp, delay = 0 }: KPICardProps) => {
  const Icon = iconMap[icon];

  return (
    <div
      className="glass-card rounded-xl p-6 stat-glow opacity-0 animate-fade-in"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="p-2.5 rounded-lg bg-primary/10">
          <Icon className="h-5 w-5 text-primary" />
        </div>
        {trend && (
          <span className={`text-xs font-medium px-2 py-1 rounded-full ${trendUp ? "bg-accent/10 text-accent" : "bg-destructive/10 text-destructive"}`}>
            {trend}
          </span>
        )}
      </div>
      <p className="text-sm text-muted-foreground font-medium">{title}</p>
      <p className="text-3xl font-bold text-card-foreground mt-1 font-mono">{value}</p>
      <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
    </div>
  );
};

export default KPICard;
