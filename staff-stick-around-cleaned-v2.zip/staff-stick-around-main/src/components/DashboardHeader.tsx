import { Database, BarChart3, FileText, Briefcase } from "lucide-react";
import { useState } from "react";

interface Tab {
  id: string;
  label: string;
  icon: React.ElementType;
}

const tabs: Tab[] = [
  { id: "dashboard", label: "Dashboard", icon: BarChart3 },
  { id: "insights", label: "Insights", icon: FileText },
  { id: "resume", label: "Resume & SQL", icon: Briefcase },
];

interface DashboardHeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const DashboardHeader = ({ activeTab, onTabChange }: DashboardHeaderProps) => (
  <header className="border-b border-border bg-card/50 backdrop-blur-xl sticky top-0 z-50">
    <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-primary/10">
          <Database className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-foreground">HR Attrition Analytics</h1>
          <p className="text-xs text-muted-foreground">Employee Turnover Analysis Dashboard</p>
        </div>
      </div>
      <nav className="flex gap-1 bg-muted rounded-lg p-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === tab.id
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </nav>
    </div>
  </header>
);

export default DashboardHeader;
