import { Lightbulb, TrendingUp, AlertTriangle, CheckCircle2 } from "lucide-react";

const insights = [
  { icon: AlertTriangle, color: "text-accent", text: "Employees with salary below $4,000 show significantly higher attrition rates, indicating compensation as a primary driver of turnover." },
  { icon: TrendingUp, color: "text-primary", text: "Younger employees (20-30 age group) exhibit the highest attrition, suggesting a need for better early-career engagement programs." },
  { icon: Lightbulb, color: "text-chart-6", text: "Low job satisfaction (rating 1-2) correlates with 2x higher attrition compared to highly satisfied employees." },
  { icon: AlertTriangle, color: "text-destructive", text: "Employees with less than 3 years of tenure are most likely to leave — the first 2 years are the critical retention window." },
  { icon: TrendingUp, color: "text-chart-3", text: "The Sales and HR departments show the highest attrition rates, requiring targeted retention strategies." },
  { icon: Lightbulb, color: "text-chart-4", text: "Work-life balance scores of 1-2 contribute to a 25% increase in attrition probability compared to balanced employees." },
  { icon: CheckCircle2, color: "text-primary", text: "Performance ratings show minimal correlation with attrition — high performers leave at similar rates, indicating dissatisfaction beyond performance." },
];

const recommendations = [
  {
    title: "Revise Compensation Strategy",
    description: "Implement competitive salary benchmarking for roles below $4,000. Introduce performance-based bonuses and retention bonuses for critical first 2 years.",
  },
  {
    title: "Early-Career Engagement Program",
    description: "Launch structured onboarding, mentorship, and 90-day check-in programs targeting employees aged 20-30 with less than 3 years tenure.",
  },
  {
    title: "Department-Specific Retention Plans",
    description: "Develop tailored retention strategies for Sales and HR departments, including career pathing, role rotation, and satisfaction pulse surveys.",
  },
];

const InsightsSection = () => (
  <div className="space-y-8">
    <div>
      <h2 className="text-2xl font-bold text-foreground mb-1">Key Business Insights</h2>
      <p className="text-muted-foreground text-sm">Data-driven findings from the attrition analysis</p>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {insights.map((item, i) => (
        <div key={i} className="glass-card rounded-xl p-5 flex gap-4 items-start opacity-0 animate-fade-in" style={{ animationDelay: `${i * 80}ms` }}>
          <item.icon className={`h-5 w-5 ${item.color} mt-0.5 shrink-0`} />
          <p className="text-sm text-card-foreground leading-relaxed">{item.text}</p>
        </div>
      ))}
    </div>

    <div className="mt-12">
      <h2 className="text-2xl font-bold text-foreground mb-1">HR Recommendations</h2>
      <p className="text-muted-foreground text-sm mb-6">Actionable strategies to reduce attrition</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {recommendations.map((rec, i) => (
          <div key={i} className="glass-card rounded-xl p-6 border-t-2 border-t-primary opacity-0 animate-fade-in" style={{ animationDelay: `${i * 100}ms` }}>
            <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2">Recommendation {i + 1}</div>
            <h3 className="font-semibold text-card-foreground mb-2">{rec.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{rec.description}</p>
          </div>
        ))}
      </div>
    </div>
  </div>
);

export default InsightsSection;
