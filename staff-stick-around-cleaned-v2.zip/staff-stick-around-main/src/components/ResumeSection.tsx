import { Copy, CheckCircle2 } from "lucide-react";
import { useState } from "react";

const resumeBullets = [
  "Analyzed HR dataset of 1,470+ employees using SQL, Excel, and Power BI to identify key attrition drivers — uncovering that low compensation (<$4K) and poor work-life balance increased turnover by 25-35%.",
  "Built an interactive KPI dashboard in Power BI tracking attrition rate (16.1%), department-wise trends, salary analysis, and satisfaction metrics — enabling data-driven decision-making for HR leadership.",
  "Delivered 7 actionable business insights and 3 strategic HR recommendations that projected a 15-20% reduction in employee attrition through targeted compensation and engagement programs.",
  "Performed end-to-end data analysis pipeline: data cleaning (handling missing values, outlier treatment), exploratory analysis (correlation, trend analysis), and visualization — demonstrating proficiency in the complete analytics workflow.",
];

const sqlQueries = [
  { title: "Overall Attrition Rate", query: "SELECT \n  ROUND(COUNT(CASE WHEN Attrition = 'Yes' THEN 1 END) * 100.0 / COUNT(*), 1) AS attrition_rate\nFROM hr_employees;" },
  { title: "Attrition by Department", query: "SELECT Department,\n  COUNT(*) AS total,\n  SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) AS left_count,\n  ROUND(SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS attrition_pct\nFROM hr_employees\nGROUP BY Department\nORDER BY attrition_pct DESC;" },
  { title: "Salary vs Attrition", query: "SELECT \n  CASE \n    WHEN Salary < 4000 THEN 'Below 4K'\n    WHEN Salary BETWEEN 4000 AND 8000 THEN '4K-8K'\n    ELSE 'Above 8K'\n  END AS salary_band,\n  ROUND(AVG(CASE WHEN Attrition = 'Yes' THEN 1.0 ELSE 0 END) * 100, 1) AS attrition_rate\nFROM hr_employees\nGROUP BY salary_band;" },
];

const ResumeSection = () => {
  const [copied, setCopied] = useState<number | null>(null);

  const copyBullet = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopied(index);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="space-y-10">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Resume-Ready Bullets</h2>
        <p className="text-muted-foreground text-sm mb-6">Click to copy — paste directly into your resume</p>
        <div className="space-y-3">
          {resumeBullets.map((bullet, i) => (
            <div
              key={i}
              onClick={() => copyBullet(bullet, i)}
              className="glass-card rounded-xl p-5 cursor-pointer hover:border-primary/50 transition-all group flex gap-4 items-start"
            >
              <span className="text-primary font-mono font-bold text-sm mt-0.5">0{i + 1}</span>
              <p className="text-sm text-card-foreground leading-relaxed flex-1">{bullet}</p>
              <div className="shrink-0 mt-0.5">
                {copied === i ? (
                  <CheckCircle2 className="h-4 w-4 text-chart-3" />
                ) : (
                  <Copy className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">SQL Queries</h2>
        <p className="text-muted-foreground text-sm mb-6">Key queries used in the analysis</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {sqlQueries.map((q, i) => (
            <div key={i} className="glass-card rounded-xl p-5">
              <h4 className="text-xs font-semibold text-primary uppercase tracking-wider mb-3">{q.title}</h4>
              <pre className="text-xs font-mono text-muted-foreground whitespace-pre-wrap leading-relaxed bg-muted/50 rounded-lg p-3 overflow-x-auto">
                {q.query}
              </pre>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ResumeSection;
