import { useState } from "react";
import DashboardHeader from "@/components/DashboardHeader";
import KPICard from "@/components/KPICard";
import AttritionCharts from "@/components/AttritionCharts";
import InsightsSection from "@/components/InsightsSection";
import ResumeSection from "@/components/ResumeSection";
import {
  totalEmployees, attritionCount, attritionRate, avgSalary, avgSatisfaction, avgTenure
} from "@/data/hrData";

const Index = () => {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="min-h-screen bg-background dark">
      <DashboardHeader activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "dashboard" && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-1">Key Performance Indicators</h2>
              <p className="text-muted-foreground text-sm">Overview of workforce metrics from 1,470 employees</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <KPICard title="Total Employees" value={totalEmployees.toLocaleString()} subtitle="Active workforce" icon="users" delay={0} />
              <KPICard title="Attrition Count" value={attritionCount.toString()} subtitle="Employees left" icon="trending" trend="High" trendUp={false} delay={80} />
              <KPICard title="Attrition Rate" value={`${attritionRate}%`} subtitle="Overall turnover" icon="activity" trend="Critical" trendUp={false} delay={160} />
              <KPICard title="Avg Salary" value={`$${avgSalary.toLocaleString()}`} subtitle="Monthly average" icon="dollar" delay={240} />
              <KPICard title="Avg Satisfaction" value={`${avgSatisfaction}/4`} subtitle="Job satisfaction" icon="star" delay={320} />
              <KPICard title="Avg Tenure" value={`${avgTenure} yrs`} subtitle="Years at company" icon="clock" delay={400} />
            </div>

            <div>
              <h2 className="text-2xl font-bold text-foreground mb-1">Analysis Dashboard</h2>
              <p className="text-muted-foreground text-sm mb-6">Interactive visualizations of attrition patterns</p>
              <AttritionCharts />
            </div>
          </div>
        )}

        {activeTab === "insights" && <InsightsSection />}
        {activeTab === "resume" && <ResumeSection />}
      </main>

      <footer className="border-t border-border py-6 mt-12">
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between text-xs text-muted-foreground">
          <span>HR Analytics Project • Data Analyst Portfolio</span>
          <span>Tools: SQL • Excel • Power BI • Python</span>
        </div>
      </footer>
    </div>
  );
};

export default Index;
