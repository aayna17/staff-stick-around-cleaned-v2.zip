export interface Employee {
  id: number;
  age: number;
  gender: "Male" | "Female";
  department: string;
  jobRole: string;
  salary: number;
  yearsAtCompany: number;
  jobSatisfaction: number;
  workLifeBalance: number;
  performanceRating: number;
  attrition: boolean;
}

const departments = ["Sales", "R&D", "HR", "Marketing", "IT"];
const jobRoles: Record<string, string[]> = {
  Sales: ["Sales Executive", "Sales Representative", "Account Manager"],
  "R&D": ["Research Scientist", "Lab Technician", "Research Director"],
  HR: ["HR Executive", "HR Manager", "Recruiter"],
  Marketing: ["Marketing Analyst", "Content Strategist", "Brand Manager"],
  IT: ["Software Engineer", "Data Analyst", "System Admin"],
};

function seededRandom(seed: number) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function generateEmployees(): Employee[] {
  const employees: Employee[] = [];
  for (let i = 1; i <= 1470; i++) {
    const r = (offset: number) => seededRandom(i * 13 + offset);
    const dept = departments[Math.floor(r(1) * departments.length)];
    const roles = jobRoles[dept];
    const role = roles[Math.floor(r(2) * roles.length)];
    const age = Math.floor(r(3) * 40) + 20;
    const yearsAtCompany = Math.floor(r(4) * Math.min(age - 18, 30));
    const salary = Math.floor(r(5) * 12000) + 2000;
    const jobSatisfaction = Math.floor(r(6) * 4) + 1;
    const workLifeBalance = Math.floor(r(7) * 4) + 1;
    const performanceRating = Math.floor(r(8) * 2) + 3;

    // Attrition probability influenced by satisfaction, salary, years
    let attritionProb = 0.16;
    if (jobSatisfaction <= 2) attritionProb += 0.15;
    if (salary < 4000) attritionProb += 0.1;
    if (yearsAtCompany < 3) attritionProb += 0.08;
    if (workLifeBalance <= 2) attritionProb += 0.07;
    if (age < 30) attritionProb += 0.05;

    employees.push({
      id: i,
      age,
      gender: r(9) > 0.42 ? "Male" : "Female",
      department: dept,
      jobRole: role,
      salary,
      yearsAtCompany,
      jobSatisfaction,
      workLifeBalance,
      performanceRating,
      attrition: r(10) < attritionProb,
    });
  }
  return employees;
}

export const employees = generateEmployees();

export const totalEmployees = employees.length;
export const attritionCount = employees.filter((e) => e.attrition).length;
export const attritionRate = ((attritionCount / totalEmployees) * 100).toFixed(1);
export const avgSalary = Math.round(employees.reduce((s, e) => s + e.salary, 0) / totalEmployees);
export const avgSatisfaction = (employees.reduce((s, e) => s + e.jobSatisfaction, 0) / totalEmployees).toFixed(1);
export const avgTenure = (employees.reduce((s, e) => s + e.yearsAtCompany, 0) / totalEmployees).toFixed(1);

export function attritionByDepartment() {
  const depts: Record<string, { total: number; attrition: number }> = {};
  employees.forEach((e) => {
    if (!depts[e.department]) depts[e.department] = { total: 0, attrition: 0 };
    depts[e.department].total++;
    if (e.attrition) depts[e.department].attrition++;
  });
  return Object.entries(depts).map(([name, d]) => ({
    name,
    rate: +((d.attrition / d.total) * 100).toFixed(1),
    total: d.total,
    attrition: d.attrition,
  }));
}

export function attritionByAgeGroup() {
  const groups: Record<string, { total: number; attrition: number }> = {
    "20-25": { total: 0, attrition: 0 },
    "26-30": { total: 0, attrition: 0 },
    "31-35": { total: 0, attrition: 0 },
    "36-40": { total: 0, attrition: 0 },
    "41-45": { total: 0, attrition: 0 },
    "46-50": { total: 0, attrition: 0 },
    "51+": { total: 0, attrition: 0 },
  };
  employees.forEach((e) => {
    const key =
      e.age <= 25 ? "20-25" : e.age <= 30 ? "26-30" : e.age <= 35 ? "31-35" :
      e.age <= 40 ? "36-40" : e.age <= 45 ? "41-45" : e.age <= 50 ? "46-50" : "51+";
    groups[key].total++;
    if (e.attrition) groups[key].attrition++;
  });
  return Object.entries(groups).map(([name, d]) => ({
    name,
    rate: +((d.attrition / d.total) * 100).toFixed(1),
    total: d.total,
    attrition: d.attrition,
  }));
}

export function salaryVsAttrition() {
  const ranges = [
    { label: "<4K", min: 0, max: 4000 },
    { label: "4K-6K", min: 4000, max: 6000 },
    { label: "6K-8K", min: 6000, max: 8000 },
    { label: "8K-10K", min: 8000, max: 10000 },
    { label: "10K+", min: 10000, max: Infinity },
  ];
  return ranges.map((r) => {
    const group = employees.filter((e) => e.salary >= r.min && e.salary < r.max);
    const att = group.filter((e) => e.attrition).length;
    return { name: r.label, rate: group.length ? +((att / group.length) * 100).toFixed(1) : 0, total: group.length };
  });
}

export function satisfactionVsAttrition() {
  return [1, 2, 3, 4].map((level) => {
    const group = employees.filter((e) => e.jobSatisfaction === level);
    const att = group.filter((e) => e.attrition).length;
    return {
      name: level === 1 ? "Low" : level === 2 ? "Medium" : level === 3 ? "High" : "Very High",
      rate: +((att / group.length) * 100).toFixed(1),
      total: group.length,
      attrition: att,
    };
  });
}

export function tenureVsAttrition() {
  const ranges = [
    { label: "0-2 yrs", min: 0, max: 3 },
    { label: "3-5 yrs", min: 3, max: 6 },
    { label: "6-10 yrs", min: 6, max: 11 },
    { label: "11-15 yrs", min: 11, max: 16 },
    { label: "16+ yrs", min: 16, max: Infinity },
  ];
  return ranges.map((r) => {
    const group = employees.filter((e) => e.yearsAtCompany >= r.min && e.yearsAtCompany < r.max);
    const att = group.filter((e) => e.attrition).length;
    return { name: r.label, rate: group.length ? +((att / group.length) * 100).toFixed(1) : 0, total: group.length };
  });
}

export function genderDistribution() {
  const male = employees.filter(e => e.gender === "Male");
  const female = employees.filter(e => e.gender === "Female");
  return [
    { name: "Male", total: male.length, attrition: male.filter(e => e.attrition).length, rate: +((male.filter(e => e.attrition).length / male.length) * 100).toFixed(1) },
    { name: "Female", total: female.length, attrition: female.filter(e => e.attrition).length, rate: +((female.filter(e => e.attrition).length / female.length) * 100).toFixed(1) },
  ];
}
